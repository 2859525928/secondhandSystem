package com.example.demo090.service;

public interface IErrorCode {
    long getCode();

    String getMessage();

}
