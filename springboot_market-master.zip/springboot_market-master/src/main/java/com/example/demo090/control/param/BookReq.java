package com.example.demo090.control.param;

import lombok.Data;

@Data
public class BookReq {
    private String name;

    private Double price;
}
