package com.example.demo090.dao.entity;

import lombok.Data;

@Data
public class ChangeIDWithStatus {
    Long comID;
}
