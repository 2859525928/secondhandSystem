package com.example.demo090;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan(basePackages = {"com.example.demo090.service"})
@SpringBootApplication
public class Demo090Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo090Application.class, args);

    }

}
