package com.example.demo090.onlyoneproperties;

import lombok.Data;

@Data
public class OnlyComID {
    private Long comID;
}
