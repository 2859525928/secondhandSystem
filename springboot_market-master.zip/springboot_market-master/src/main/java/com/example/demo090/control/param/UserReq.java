package com.example.demo090.control.param;

import lombok.Data;

@Data
public class UserReq {

    private String username;

    private String password;

    private String telephonenum;

}
